def add_one(n):
    return n + 1
